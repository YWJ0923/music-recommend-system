package com.music_recommend_system.front.dao;

import com.music_recommend_system.front.entity.Tag;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author ywj
 * @Date 2022/02/10
 */
@Repository
public interface TagMapper {
    /**
     * 查询所有标签
     * @return
     */
    List<Tag> listTags();

    /**
     * 插入用户喜好的标签
     * @param userId
     * @param tags
     * @return
     */
    int insertUserTags(@Param("userId") Integer userId, @Param("tags") List<Integer> tags);
}
